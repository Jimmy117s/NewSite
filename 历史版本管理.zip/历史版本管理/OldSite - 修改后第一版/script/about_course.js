// JavaScript Document

/*
$(document).ready(function(){
	//$(".about_course dl:gt(0)").hide();	
	$(".course_title:eq(0)").addClass("act");
	
	$(".course_title").click(function(){
		$(this).toggleClass("act");
		$(this).next("dl").slideToggle();
	});		
	
	$(".about_course .history_close img").click(function(){
		$(this).parents("dl").slideUp()
		.prev().removeClass("act");;
		//$(this).parents("dl").prev().removeClass("act");
	});
});
*/

$(function(){
	$(".history_tab li:eq(0)").addClass("curr");
	$(".history_item:gt(0)").hide();
	
	$(".history_tab li").click(function(){
		$(".history_tab li").removeClass("curr");
		$(this).addClass("curr");
		history_id=parseInt($(this).attr("id"));
		$(".history_item:visible").hide();
		$(".history_item").eq(history_id).show();
	});		   
});