// JavaScript Document
var banner_currId=0;
var imgCount;
var timeout;
var interval=3000;
$(function(){
	   imgCount=$(".banner .imgs li").length;
	   $(".banner .imgs li:gt(0)").hide();
	   $(".banner .num li:eq(0)").addClass("curr");
	   timeout=setTimeout("banner_change(1)",interval);
	   
	   $(".banner .num li").click(function(){
			cid=parseInt($(this).attr("id"));
			clearTimeout(timeout);
			banner_change(cid);
		});
	   
});

function banner_change(currId){
	banner_currId=currId;
	$(".banner .imgs li:visible").fadeOut(1000);
	$(".banner .imgs li").eq(currId).fadeIn(1000);
	$(".banner .num li").removeClass("curr");
	$(".banner .num li").eq(currId).addClass("curr");
	banner_currId++;
	if(banner_currId>=imgCount) banner_currId=0;
	timeout=setTimeout("banner_change(banner_currId)",interval);
}