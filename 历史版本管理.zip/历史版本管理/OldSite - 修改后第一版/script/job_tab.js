// JavaScript Document

$(function(){
	$("#job_tab table:gt(0)").hide();	
	$("#job_tab ul li").click(function(){
		job_id=parseInt($(this).attr("id"))-1;
		//job_id_num=parseInt(job_id);
		$("#job_tab ul li").removeClass("act");
		$(this).addClass("act");
		$("#job_tab table:visible").hide();
		$("#job_tab table").eq(job_id).show();
	});
});