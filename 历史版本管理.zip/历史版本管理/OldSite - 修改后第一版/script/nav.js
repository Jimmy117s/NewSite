// JavaScript Document

$(function(){
	nav_curr();	   
		   
	//下拉菜单
	$("#menu > li:has(.subMenu)").hover(function(){
		//$("#menu > li > a").removeClass("hover");	
		$(this).find("a").eq(0).addClass("hover");
		$(this).find(".subMenu").stop(true,true).fadeIn(300);
	},function(){
		$(this).find("a").eq(0).removeClass("hover");
		$(this).find(".subMenu").stop(true,true).fadeOut(300);
		nav_curr();
	});		
	
	//导航当前项
	function nav_curr(){
	for(var i=0;i<7;i++){
		navText=$("#menu > li > a").eq(i).attr("title");	
		if(navText==navCurrent){
				$("#menu > li > a").eq(i).addClass("hover");
		}
	}
	}
	
	//选择语言
	//$("#language .select").hover(function(){
		//$(this).addClass("act");							  
	//},function(){
		//$(this).removeClass("act");
	//});	
	
});