// JavaScript Document
//导航当前项
$(function(){  
	for(var i=0;i<6;i++){
		navText=$("#menu a").eq(i).html();	
		
		if(navText==navCurrent){
				$("#menu a").eq(i).addClass("hover");
		}
	}	   
		   
		   });
	