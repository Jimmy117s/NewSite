// JavaScript Document
$(function () {
    //顶部菜单导航
    $(".nav li").hover(function () {
        $(this).find('div').stop().slideDown(180);
    }, function () {
        $(this).find('div').stop().slideUp(180);
    });
    //新闻向上滚动
    setInterval(function AutoScroll() {
        $('#news_scroll').find("ul:first").animate({
            marginTop: "-25px"
        }, 1000, function () {
            $(this).css({ marginTop: "0px" }).find("li:first").appendTo(this);
        });
    }, 3500)
    //客户列表滚动
    $(".jCarouselLite").jCarouselLite({
        auto: 1000,
        scroll: 1,
        speed: 1000,
        visible: 7
    });
    //内容页左边导航
    $(".left_nav dl").click(function () {
        $(this).addClass("left_nav_select")
          .children("dd").show('slow').end()
          .siblings().removeClass("left_nav_select")
          .children("dd").hide('slow')
    });
    //左边导航固定
    $(window).scroll(function () {
        var TopHeight = $('#header').height() + $('#banner').height();
        if ($(window).scrollTop() >= TopHeight) {
            $('.left_nav').addClass('topFixed');
        } else {
            $('.left_nav').removeClass('topFixed');
        }
    });
    //banner
    var speed = 3000;//延时设定，默认设置3秒
    var imgsrc = 'images/circle.png';// 小按钮图片地址
    var imgsrc2 = 'images/circle_select.png';// 小按钮点击状态图片地址	
    var imgm = $(".bannerul li").length;//获取li数量
    var imgw = $(".bannerul img ").width();//获取图片宽度
    $(".bannerul").css({ width: imgw * imgm });//设定ul容器宽度
    n = -1//全局参数n  自动循环时应用的参数
    for (i = 0; i < imgm; i++) {//循环li数量的按钮（需要修改图片地址请在这里修改）
        $(".bannerd").append('<img src="' + imgsrc + '" id=' + i + ' />');//在容器bannerd中循环出居中的按钮图片。（需要将按钮放到图片上的，请修改容器的css相对定位）
    }
    $(".bannerd img:eq(0)").attr({ src: imgsrc2 });//设定第一按钮为点击状态的按钮图片
    $(".bannerd img").click(function () {//点击按钮时跳转到相对应图片 且切换按钮图片
        $(".bannerd img").attr({ src: imgsrc });
        $(this).attr({ src: imgsrc2 });
        n = $(this).attr("id")
        $(".bannerul").animate({ left: -imgw * $(this).attr("id") });

    });
    function bsi() {//设定自动播放函数
        if (n < imgm - 1) {//判定是否移动到最后一个图片
            n++;
            $(".bannerd img").attr({ src: imgsrc });
            $(".bannerd img:eq(" + n + ")").attr({ src: imgsrc2 });
            $(".bannerul").animate({ left: -imgw * n });
        }
        else {//移动到最后一个时重置函数n再次循环			
            n = -1
            $(".bannerd img").attr({ src: imgsrc });
            $(".bannerd img:eq(0)").attr({ src: imgsrc2 });
            $(".bannerul").animate({ left: 0 });
        }
    }
    var Mysl = setInterval(bsi, speed)//自动播放
    $(".bannerul,.bannerd img").mouseover(function () { clearInterval(Mysl) })//鼠标划过时  停止自动播放
    $(".bannerul,.bannerd img").mouseout(function () { Mysl = setInterval(bsi, speed) })//鼠标离开时  重置自动播放	
});








